package com.csus.csc133.models;

public class StudentCar extends Student{

    // default constructor
    public StudentCar(int x, int y) {
        super(x, y);
        sweatingRate = 0;
        head = 90;
    }
}
