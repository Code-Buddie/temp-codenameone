package com.csus.csc133.models;

public class StudentRunning extends Student{
	
    // default constructor
    public StudentRunning(int x, int y) {
        super(x, y);
        sweatingRate = 2;
    }
}
